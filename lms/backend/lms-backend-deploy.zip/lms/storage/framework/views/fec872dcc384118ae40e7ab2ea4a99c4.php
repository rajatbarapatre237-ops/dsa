<?php $__env->startSection('title', $page->title . ' — ' . config('app.name', 'DSA Edu')); ?>

<?php $__env->startSection('content'); ?>
    <article class="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
        <h1 class="text-3xl font-bold text-slate-900"><?php echo e($page->title); ?></h1>
        <div class="mt-6 space-y-3 leading-relaxed text-slate-700">
            <?php echo $page->body; ?>

        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrakantarya/Desktop/my-projects/dsa/lms/backend/lms/resources/views/public/page.blade.php ENDPATH**/ ?>