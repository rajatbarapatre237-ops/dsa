<div>
    <h1 class="text-2xl font-bold text-slate-900">Contact Queries</h1>
    <p class="mt-1 text-slate-600">Messages submitted from the public contact form.</p>

    <div class="mt-6 overflow-hidden rounded-xl border border-slate-200 bg-white">
        <table class="min-w-full text-sm">
            <thead class="bg-slate-50 text-left text-xs font-bold uppercase tracking-wide text-slate-500">
                <tr>
                    <th class="px-4 py-3">Date</th>
                    <th class="px-4 py-3">Name</th>
                    <th class="px-4 py-3">Email</th>
                    <th class="px-4 py-3">Message</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $queries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr class="<?php echo e($query->is_read ? '' : 'bg-sky-50/50'); ?>">
                        <td class="px-4 py-3 whitespace-nowrap text-slate-500">
                            <?php echo e(optional($query->created_at)->format('d M Y, H:i') ?? '—'); ?>

                        </td>
                        <td class="px-4 py-3 font-semibold"><?php echo e($query->name); ?></td>
                        <td class="px-4 py-3"><a href="mailto:<?php echo e($query->email); ?>" class="text-sky-700 hover:underline"><?php echo e($query->email); ?></a></td>
                        <td class="max-w-xs px-4 py-3 text-slate-600"><?php echo e(\Illuminate\Support\Str::limit($query->message, 120)); ?></td>
                        <td class="px-4 py-3">
                            <span class="rounded-full px-2 py-1 text-xs font-bold <?php echo e($query->is_read ? 'bg-slate-100 text-slate-600' : 'bg-sky-100 text-sky-700'); ?>">
                                <?php echo e($query->is_read ? 'Read' : 'New'); ?>

                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <div class="flex flex-wrap gap-2">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($query->is_read): ?>
                                    <button wire:click="markUnread(<?php echo e($query->id); ?>)" class="text-xs font-semibold text-slate-600 hover:underline">Mark unread</button>
                                <?php else: ?>
                                    <button wire:click="markRead(<?php echo e($query->id); ?>)" class="text-xs font-semibold text-sky-700 hover:underline">Mark read</button>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <button wire:click="deleteQuery(<?php echo e($query->id); ?>)" wire:confirm="Delete this query?" class="text-xs font-semibold text-red-600 hover:underline">Delete</button>
                            </div>
                        </td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <tr>
                        <td colspan="6" class="px-4 py-8 text-center text-slate-500">No contact queries yet.</td>
                    </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($queries->links()); ?>

    </div>
</div>
<?php /**PATH /Users/chandrakantarya/Desktop/my-projects/dsa/lms/backend/lms/resources/views/livewire/dashboard/contact-queries.blade.php ENDPATH**/ ?>