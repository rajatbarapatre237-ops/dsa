<?php $__env->startSection('title', 'Home — ' . config('app.name', 'DSA Edu')); ?>

<?php $__env->startSection('content'); ?>
    <div class="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
        <h1 class="text-3xl font-bold text-slate-900">Welcome to <?php echo e(config('app.name', 'DSA Edu')); ?></h1>
        <p class="mt-3 max-w-2xl text-slate-600">Learning management for students, teachers, and parents.</p>
        <div class="mt-8 flex flex-wrap gap-3">
            <a href="<?php echo e(route('pages.about')); ?>" class="rounded-lg bg-sky-700 px-4 py-2 text-sm font-semibold text-white hover:bg-sky-800">About Us</a>
            <a href="<?php echo e(route('contact.show')); ?>" class="rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold hover:bg-slate-50">Contact Us</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chandrakantarya/Desktop/my-projects/dsa/lms/backend/lms/resources/views/public/home.blade.php ENDPATH**/ ?>