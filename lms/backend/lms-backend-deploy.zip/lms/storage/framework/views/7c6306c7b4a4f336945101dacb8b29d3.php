<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard — <?php echo e(config('app.name', 'DSA Edu')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="min-h-screen bg-slate-100 text-slate-800 antialiased">
    <div class="flex min-h-screen">
        <aside class="w-64 shrink-0 border-r border-slate-200 bg-white p-5">
            <a href="<?php echo e(route('dashboard.home')); ?>" class="mb-2 block text-lg font-bold text-sky-700">DSA Dashboard</a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('dashboard_admin_username')): ?>
                <p class="mb-8 text-xs text-slate-500">Signed in as <?php echo e(session('dashboard_admin_username')); ?></p>
            <?php else: ?>
                <div class="mb-8"></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <nav class="space-y-1 text-sm font-medium">
                <a href="<?php echo e(route('dashboard.home')); ?>" class="block rounded-lg px-3 py-2 hover:bg-sky-50 <?php echo e(request()->routeIs('dashboard.home') ? 'bg-sky-50 text-sky-700' : ''); ?>">Overview</a>
                <p class="px-3 pt-4 text-xs font-bold uppercase tracking-wide text-slate-400">Pages</p>
                <a href="<?php echo e(route('dashboard.pages.edit', 'privacy-policy')); ?>" class="block rounded-lg px-3 py-2 hover:bg-sky-50 <?php echo e(request()->is('dashboard/pages/privacy-policy') ? 'bg-sky-50 text-sky-700' : ''); ?>">Privacy Policy</a>
                <a href="<?php echo e(route('dashboard.pages.edit', 'terms')); ?>" class="block rounded-lg px-3 py-2 hover:bg-sky-50 <?php echo e(request()->is('dashboard/pages/terms') ? 'bg-sky-50 text-sky-700' : ''); ?>">Terms</a>
                <a href="<?php echo e(route('dashboard.pages.edit', 'about-us')); ?>" class="block rounded-lg px-3 py-2 hover:bg-sky-50 <?php echo e(request()->is('dashboard/pages/about-us') ? 'bg-sky-50 text-sky-700' : ''); ?>">About Us</a>
                <p class="px-3 pt-4 text-xs font-bold uppercase tracking-wide text-slate-400">Inbox</p>
                <a href="<?php echo e(route('dashboard.contact-queries')); ?>" class="block rounded-lg px-3 py-2 hover:bg-sky-50 <?php echo e(request()->routeIs('dashboard.contact-queries') ? 'bg-sky-50 text-sky-700' : ''); ?>">Contact Queries</a>
            </nav>
            <form method="POST" action="<?php echo e(route('dashboard.logout')); ?>" class="mt-8">
                <?php echo csrf_field(); ?>
                <button type="submit" class="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold hover:bg-slate-50">Logout</button>
            </form>
        </aside>
        <main class="flex-1 p-8">
            <?php echo e($slot); ?>

        </main>
    </div>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH /Users/chandrakantarya/Desktop/my-projects/dsa/lms/backend/lms/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>