# DSA LMS API — server setup

1. Upload `lms-api-deploy.zip` and extract on the server.
2. Point domain document root to the **`public/`** folder (important).
3. Set **PHP 8.4** in cPanel → MultiPHP Manager for this domain.
4. Open in browser:

```
https://YOUR-DOMAIN/setup.php
```

When you see `"status":"success"`, the API is ready at:

```
https://YOUR-DOMAIN/api/v1
```

**Before step 4:** edit `.env` if needed (`APP_URL`, `DB_*`).

**PHP version:** requires **PHP 8.4.1 or newer**.

**404?** Document root must be `public/`, not the parent `lms-api/` folder.

**Mobile apps:** set `API_BASE_URL` to `https://YOUR-DOMAIN/api/v1`.
