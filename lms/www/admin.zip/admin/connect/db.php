<?php
class connect{

public $servername = "localhost";
    private $username = "dsaedu_dsa";
    private $password = "dsaedu_dsa";
    private $dbname = "dsaedu_dsa";
    //create connection

    public function dbconnect()
	{
		$db=mysqli_connect($this->servername,$this->username,$this->password,$this->dbname);
		
		return $db;
	}
}


?>